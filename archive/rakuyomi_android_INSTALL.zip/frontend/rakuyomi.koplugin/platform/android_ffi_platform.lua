-- Android FFI Platform for Rakuyomi
-- This uses FFI to load librakuyomi.so directly instead of spawning a process

local logger = require('logger')
local ffi = require('ffi')
local Paths = require('Paths')
local rapidjson = require('rapidjson')

-- Define the C interface
ffi.cdef[[
    int rakuyomi_init(const char* config_path);
    char* rakuyomi_get_sources(void);
    char* rakuyomi_search(const char* source_id, const char* query);
    char* rakuyomi_get_manga(const char* source_id, const char* manga_id);
    char* rakuyomi_get_chapters(const char* source_id, const char* manga_id);
    char* rakuyomi_get_pages(const char* source_id, const char* manga_id, const char* chapter_id);
    int rakuyomi_download_page(const char* source_id, const char* manga_id, const char* chapter_id, const char* page_url, const char* output_path);
    int rakuyomi_health_check(void);
    void rakuyomi_free_string(char* s);
    char* rakuyomi_get_library(void);
    int rakuyomi_add_to_library(const char* source_id, const char* manga_id, const char* manga_json);
    int rakuyomi_remove_from_library(const char* source_id, const char* manga_id);
    char* rakuyomi_get_settings(void);
    int rakuyomi_set_settings(const char* settings_json);
    char* rakuyomi_get_notification_count(void);
    char* rakuyomi_get_available_sources(void);
    int rakuyomi_install_source(const char* source_id, const char* source_url);
]]

-- Try to load the shared library
local function load_rakuyomi_library()
    local plugin_lib = Paths.getPluginDirectory() .. "/libs/librakuyomi.so"
    local private_lib = "/data/data/org.koreader.launcher/files/librakuyomi.so"
    
    logger.info("Plugin library path: " .. plugin_lib)
    logger.info("Private library path: " .. private_lib)
    
    local function file_exists(path)
        local f = io.open(path, "r")
        if f then f:close() return true end
        return false
    end
    
    local plugin_exists = file_exists(plugin_lib)
    logger.info("Plugin library exists: " .. tostring(plugin_exists))
    
    local private_exists = file_exists(private_lib)
    logger.info("Private library exists: " .. tostring(private_exists))
    
    if plugin_exists and not private_exists then
        logger.info("Extracting library from plugin to private directory")
        local src = io.open(plugin_lib, "rb")
        if src then
            local content = src:read("*all")
            src:close()
            local dst = io.open(private_lib, "wb")
            if dst then
                dst:write(content)
                dst:close()
                logger.info("Library extracted successfully")
            else
                logger.warn("Failed to write to private directory")
            end
        else
            logger.warn("Failed to read from plugin directory")
        end
    end
    
    local lib_paths = {
        private_lib,
        plugin_lib,
        "librakuyomi.so",
        "./librakuyomi.so",
    }
    
    for _, path in ipairs(lib_paths) do
        logger.info("Trying to load library from: " .. path)
        local ok, lib = pcall(function() return ffi.load(path) end)
        if ok and lib then
            logger.info("Successfully loaded rakuyomi library from: " .. path)
            return lib, nil
        else
            logger.info("Failed to load from " .. path .. ": " .. tostring(lib))
        end
    end
    
    return nil, "Failed to load librakuyomi.so from any location"
end

---@class AndroidFFIServer
local AndroidFFIServer = {}

function AndroidFFIServer:new(lib)
    local server = {
        lib = lib,
        logBuffer = {},
        maxLogLines = 100,
    }
    setmetatable(server, { __index = AndroidFFIServer })
    return server
end

function AndroidFFIServer:getLogBuffer()
    return self.logBuffer
end

local function addLog(self, message)
    table.insert(self.logBuffer, message)
    while #self.logBuffer > self.maxLogLines do
        table.remove(self.logBuffer, 1)
    end
    logger.info("Server output: " .. message)
end

function AndroidFFIServer:request(request)
    local path = request.path
    local method = request.method or "GET"
    local result_json = nil
    local error_msg = nil
    
    if path == "/health-check" then
        local ready = self.lib.rakuyomi_health_check()
        if ready == 1 then
            return { type = 'SUCCESS', status = 200, body = '{"status": "ok"}' }
        else
            return { type = 'ERROR', status = 503, message = "not ready" }
        end
    end
    
    if path == "/library" then
        addLog(self, "Fetching library via FFI")
        result_json = self.lib.rakuyomi_get_library()
    elseif path == "/settings" then
        if method == "GET" then
            addLog(self, "Fetching settings via FFI")
            result_json = self.lib.rakuyomi_get_settings()
        -- Accept both POST and PUT for saving settings
        elseif method == "POST" or method == "PUT" then
            addLog(self, "Setting settings via FFI")
            if request.body then
                local result = self.lib.rakuyomi_set_settings(request.body)
                if result == 0 then
                    return { type = 'SUCCESS', status = 200, body = '{}' }
                else
                    error_msg = "Failed to set settings (error: " .. tostring(result) .. ")"
                end
            else
                error_msg = "Missing request body"
            end
        end
    elseif path:match("^/mangas/[^/]+/[^/]+/add%-to%-library$") then
        addLog(self, "Adding manga to library via FFI")
        local source_id, manga_id = path:match("^/mangas/([^/]+)/([^/]+)/add%-to%-library$")
        if source_id and manga_id then
            local manga_json = request.body or "{}"
            local result = self.lib.rakuyomi_add_to_library(source_id, manga_id, manga_json)
            if result == 0 then
                return { type = 'SUCCESS', status = 200, body = '{}' }
            else
                error_msg = "Failed to add manga to library (error: " .. tostring(result) .. ")"
            end
        else
            error_msg = "Invalid path format"
        end
    elseif path:match("^/mangas/[^/]+/[^/]+/remove%-from%-library$") then
        addLog(self, "Removing manga from library via FFI")
        local source_id, manga_id = path:match("^/mangas/([^/]+)/([^/]+)/remove%-from%-library$")
        if source_id and manga_id then
            local result = self.lib.rakuyomi_remove_from_library(source_id, manga_id)
            if result == 0 then
                return { type = 'SUCCESS', status = 200, body = '{}' }
            else
                error_msg = "Failed to remove manga from library (error: " .. tostring(result) .. ")"
            end
        else
            error_msg = "Invalid path format"
        end
    elseif path == "/mangas" then
        addLog(self, "Searching mangas via FFI")
        local query = request.query_params and request.query_params.q
        if query then
            addLog(self, "Search query: " .. query)
        end
        -- Return empty array for now (stub)
        return { type = 'SUCCESS', status = 200, body = '[[], []]' }
    elseif path == "/api/sources" then
        addLog(self, "Fetching sources via FFI")
        result_json = self.lib.rakuyomi_get_sources()
    elseif path:match("^/api/search") then
        local source_id = request.query_params and request.query_params.source_id
        local query = request.query_params and request.query_params.query
        if source_id and query then
            addLog(self, "Searching source " .. source_id .. " for: " .. query)
            result_json = self.lib.rakuyomi_search(source_id, query)
        else
            error_msg = "Missing source_id or query parameter"
        end
    elseif path:match("^/api/manga$") then
        local source_id = request.query_params and request.query_params.source_id
        local manga_id = request.query_params and request.query_params.manga_id
        if source_id and manga_id then
            addLog(self, "Fetching manga " .. manga_id .. " from source " .. source_id)
            result_json = self.lib.rakuyomi_get_manga(source_id, manga_id)
        else
            error_msg = "Missing source_id or manga_id parameter"
        end
    elseif path:match("^/api/chapters$") then
        local source_id = request.query_params and request.query_params.source_id
        local manga_id = request.query_params and request.query_params.manga_id
        if source_id and manga_id then
            addLog(self, "Fetching chapters for manga " .. manga_id)
            result_json = self.lib.rakuyomi_get_chapters(source_id, manga_id)
        else
            error_msg = "Missing source_id or manga_id parameter"
        end
    elseif path:match("^/api/pages$") then
        local source_id = request.query_params and request.query_params.source_id
        local manga_id = request.query_params and request.query_params.manga_id
        local chapter_id = request.query_params and request.query_params.chapter_id
        if source_id and manga_id and chapter_id then
            addLog(self, "Fetching pages for chapter " .. chapter_id)
            result_json = self.lib.rakuyomi_get_pages(source_id, manga_id, chapter_id)
        else
            error_msg = "Missing source_id, manga_id, or chapter_id parameter"
        end
    elseif path == "/count-notifications" then
        addLog(self, "Fetching notification count via FFI")
        result_json = self.lib.rakuyomi_get_notification_count()
    elseif path == "/installed-sources" then
        addLog(self, "Fetching installed sources via FFI")
        -- Return empty array for now (stub)
        return { type = 'SUCCESS', status = 200, body = '[]' }
    elseif path == "/available-sources" then
        addLog(self, "Fetching available sources via FFI")
        result_json = self.lib.rakuyomi_get_available_sources()
    elseif path:match("^/available%-sources/[^/]+/install$") then
        addLog(self, "Installing source via FFI")
        local source_id = path:match("^/available%-sources/([^/]+)/install$")
        if source_id then
            -- The source_url should be in request.body
            local source_url = request.body or ""
            local result = self.lib.rakuyomi_install_source(source_id, source_url)
            if result == 0 then
                return { type = 'SUCCESS', status = 200, body = '[]' }
            else
                error_msg = "Failed to install source (error: " .. tostring(result) .. ")"
            end
        else
            error_msg = "Invalid source ID in path"
        end
    else
        error_msg = "Unknown endpoint: " .. path
    end
    
    if error_msg then
        return { type = 'ERROR', status = 400, message = error_msg }
    end
    
    if result_json == nil then
        return { type = 'ERROR', status = 500, message = "FFI call returned null" }
    end
    
    -- Convert C string to Lua string
    local result_str = ffi.string(result_json)
    
    -- Free the C string
    self.lib.rakuyomi_free_string(result_json)
    
    return { type = 'SUCCESS', status = 200, body = result_str }
end

function AndroidFFIServer:stop()
    -- Nothing to stop for FFI backend
    logger.info("Android FFI server stopped")
end

---@class AndroidFFIPlatform: Platform
local AndroidFFIPlatform = {}

function AndroidFFIPlatform:startServer()
    logger.info("Starting Android FFI server...")
    
    local lib, err = load_rakuyomi_library()
    if not lib then
        error("Failed to load rakuyomi library: " .. (err or "unknown error"))
    end
    
    -- Initialize with config path
    local config_path = Paths.getHomeDirectory()
    local init_result = lib.rakuyomi_init(config_path)
    
    if init_result ~= 0 then
        error("Failed to initialize rakuyomi library (error code: " .. init_result .. ")")
    end
    
    logger.info("Android FFI server initialized successfully")
    
    return AndroidFFIServer:new(lib)
end

-- Helper function to detect if we're on Android
function AndroidFFIPlatform.isAndroid()
    return os.getenv("ANDROID_ROOT") ~= nil
end

return AndroidFFIPlatform