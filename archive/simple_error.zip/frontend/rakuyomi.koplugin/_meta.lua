local _ = require("gettext+")

return {
  name = "rakuyomi",
  fullname = _("rakuyomi"),
  description = _("Download mangas on your e-book reader!")
}
